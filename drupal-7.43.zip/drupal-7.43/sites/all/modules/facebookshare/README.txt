Created by: Ralivue.com
Author: Will Steinmetz

This module was created to help users easily share links to
nodes with their friends on Facebook.

This node was created independent of Facebook and we make no
claim to be a member of Facebook or represent them in any way.

TO INSTALL:
Simply untar the Facebook Share module archive and drop the
untarred folder in the appropriate place.
EX: if you want the module to be available to all of your sites
under a Drupal install, drop it in the sites/all/modules folder.
To install the module for just specific sites under a Drupal
install, drop it in the appropriate sites/*/modules folder(s).